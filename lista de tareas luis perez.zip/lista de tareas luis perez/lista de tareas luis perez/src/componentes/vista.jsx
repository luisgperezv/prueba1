import React from 'react'
import { useState } from 'react'
export default function vista(props) {
    
    

  return (
    <div>
        
       
       <div class="alert alert-primary" role="alert">
                {props.valor}
        </div>

    </div>
  )
}
