import React from 'react'
import { useState,useEffect } from 'react'

export default function objectos() {

    
    const[nombre,setnombre]=useState("");
    const [Apellido,setapellido]=useState("");
    const [ciudad,setciudad]=useState("");
    const [edad,setedad]=useState(0);


   
    const [datos,setdatos]=useState([]);

    useEffect(()=>{
        console.log(datos);

    },[])

    function agregar(){

      
        let valores={"nombre":nombre,"apellido":Apellido,"ciudad":ciudad,"edad":edad, completada: false}
        setdatos([...datos,valores])
        setnombre("")
        setapellido("")
        setciudad("")
        setedad(0)





    }


    function eliminar(nombreEl)
    {

        let datos1=datos.filter((val)=>val.nombre !=nombreEl);
        setdatos(datos1)
        // console.log(datos1)
        
    }


 

    

    function editar(nombre,apellido,ciudad,edad){

        setnombre(nombre)
        setapellido(apellido)
        setciudad(ciudad)
        setedad(edad)
        eliminar(nombre)
    }

    function toggleCompletada(nombre) {
        setdatos(datos.map(tarea => 
            tarea.nombre === nombre ? {...tarea, completada: !tarea.completada} : tarea
        ));
    }

  return (
    <>
    
    <div className='col-md-12 colores'>
        <label htmlFor="" className='col-md-2 m-1'>Id tarea
            <input type="text" value={nombre} onChange={(e)=>{setnombre(e.target.value)}} className='form-control' />
        </label>

        <label htmlFor="" className='col-md-2 m-1'>Nombre
            <input type="text" className='form-control' value={Apellido} onChange={(e)=>{setapellido(e.target.value)}} />
        </label>

        <label htmlFor="" className='col-md-2 m-1'>Descripcion
            <input type="text" className='form-control' value={ciudad} onChange={(e)=>{setciudad(e.target.value)}} />
        </label>

        <label htmlFor="" className='col-md-2 m-1'>N° Tarea
            <input type="number" className='form-control' value={edad} onChange={(e)=>{setedad(e.target.value)}} />
        </label>

        <label  className='col-md-2 m-1'>
            <input type="button" className='btn btn-primary' onClick={(e)=>{agregar()}}  value="Agregar" />
        </label>
        
       
        
       

    </div>
    
    <div>
            <table className="table">
        <thead>
            <tr>
            <th scope="col">Id tarea</th>
            <th scope="col">Nombre</th>
            <th scope="col">Descripcion</th>
            <th scope="col">N° tarea</th>
            <th scope="col">Estado</th>
            <th scope="col">opciones</th>
            
            </tr>
        </thead>
        <tbody >
            {

                datos.map((v)=>{

                    return(

                        <tr >
                        <th scope="row">{v.nombre}</th>
                        <td>{v.apellido}</td>
                        <td>{v.ciudad}</td>
                        <td>{v.edad}</td>
                        <td>{v.completada ? 'Completada' : 'Pendiente'}</td>
                        <td><label  className='col-md-2 m-1'>
            <input type="button" className='btn btn-danger' onClick={()=>{eliminar(v.nombre)}} 
             value="Eliminar" />
        </label></td>

        <td><label  className='col-md-2 m-1'>
            <input type="button" className='btn btn-danger' onClick={()=>{editar(v.nombre,v.apellido,v.ciudad,v.id)}} 
             value="Editar" />
        </label></td>

        <td><label  className='col-md-2 m-1'>
        <input type="button" className={`btn ${v.completada ? 'btn-success' : 'btn-secondary'} m-1`} onClick={() => toggleCompletada(v.nombre)} value={v.completada ? 'Marcar como pendiente' : 'Marcar como completada'} />
        </label></td>
                    </tr>
                    )

                })
            }
           
        
        </tbody>
        </table>


    </div>
    
    <div>
        
        

    </div>
    
    </>
  )
}

