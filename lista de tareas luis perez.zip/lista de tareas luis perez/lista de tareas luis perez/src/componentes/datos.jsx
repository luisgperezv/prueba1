import React from 'react'
import { useState } from 'react'

export default function datos() {

    const [nombre,setnombre]=useState("german")
    const [i,seti]=useState(0)

 
}