import { useState } from 'react'
 import './App.css'
 import Datos from './componentes/datos'
import Objectos from './componentes/objectos'
import Vista from './componentes/vista'


import { BrowserRouter,Link } from "react-router-dom";
import { Routes, Route } from "react-router-dom";

function App() {
  

  return (
    <>

<BrowserRouter>  
   <Routes>
    <Route path="/" element={<h1>hola profe buenos dias,por favor coloque "/inicio" despues del http://localhost:5175 en el link del buscador para ir a la pagina donde esta la lista</h1>} />
    <Route path="/inicio" element={<Objectos></Objectos>} />  

   
 </Routes>

 </BrowserRouter>

    </>
  )
}

export default App
